-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aegis
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bscoe55`
--

DROP TABLE IF EXISTS `bscoe55`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bscoe55` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `studnum` varchar(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `f_grading` varchar(15) NOT NULL DEFAULT '- not set -',
  `s_grading` varchar(15) NOT NULL DEFAULT '- not set -',
  `c_rating` varchar(15) NOT NULL DEFAULT '- not set -',
  `f_rating` varchar(15) NOT NULL DEFAULT '- not set -',
  `o_remarks` varchar(45) NOT NULL DEFAULT '- not set -',
  `f_remarks` varchar(45) NOT NULL,
  PRIMARY KEY (`num`),
  UNIQUE KEY `num_UNIQUE` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bscoe55`
--

LOCK TABLES `bscoe55` WRITE;
/*!40000 ALTER TABLE `bscoe55` DISABLE KEYS */;
INSERT INTO `bscoe55` VALUES (1,'2015-08997-MN-0','ABULOC, CHRISTOPHER MATUNDIN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(2,'2015-06746-MN-0','ALTERADO, BRYXTER ANUNCIACION','- not set -','- not set -','- not set -','- not set -','- not set -',''),(3,'2015-00833-MN-0','APLACADOR, MORRIS BATINGA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(4,'2015-01807-MN-0','ATENCIO, COLYN MARIZ FLORES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(5,'2015-00758-MN-0','BALILO, GRACE JOY FLORES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(6,'2014-01458-MN-0','BATIOCO, ARVIN KENNETH YOUNG','- not set -','- not set -','- not set -','- not set -','- not set -',''),(7,'2015-04944-MN-0','BERMUDEZ, DAVID GABRIEL LIMBO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(8,'2015-01528-MN-0','BUENAVENTURA, ERIKA MAE DOMINGO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(9,'2015-00925-MN-0','BUTED, TRICIA MAE COMEROS','- not set -','- not set -','- not set -','- not set -','- not set -',''),(10,'2015-00843-MN-0','CARIAGA, JOHN RONALDO SARTE','- not set -','- not set -','- not set -','- not set -','- not set -',''),(11,'2015-03189-MN-0','CENTINO, MARYNELLE ZAPANTA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(12,'2015-00330-MN-0','COQUIA, JOSHUA MARI PADUA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(13,'2015-03443-MN-0','CORDOVA, ALEXANDER CAMACHO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(14,'2015-12889-MN-0','CUENTAS, JANZZEN MITZ ROGELLE DE LEON','- not set -','- not set -','- not set -','- not set -','- not set -',''),(15,'2015-04819-MN-0','DAYAO, LEANNE MAE REYES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(16,'2015-09571-MN-0','DE ASIS, HARROLD PABLEA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(17,'2012-02809-MN-0','DE VERA, NIKKO ORTIZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(18,'2015-08555-MN-0','DELA CRUZ, LANCE GIOLO DUEÃƒâ€˜AS','- not set -','- not set -','- not set -','- not set -','- not set -',''),(19,'2015-03139-MN-0','DELOS REYES, REYHAN ALBERT SARENAS','- not set -','- not set -','- not set -','- not set -','- not set -',''),(20,'2015-03755-MN-0','FABILLAR, KENT FREDERICK ALVAREZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(21,'2015-01721-MN-0','FRANCISCO, ELPIDIO II ANDAL','- not set -','- not set -','- not set -','- not set -','- not set -',''),(22,'2015-00130-MN-0','GALLARDA, KYLAMICAH DE GUZMAN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(23,'2015-00804-MN-0','GARCIA, BRAD LEE DONES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(24,'2015-02590-MN-0','GISULGA, CHERRY MAE PAJOTA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(25,'2015-11266-MN-0','GUANZON, JESSA CHRISTINE ANDANA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(26,'2015-00132-MN-0','GUIYAB, DANREB SABUG','- not set -','- not set -','- not set -','- not set -','- not set -',''),(27,'2015-03646-MN-0','HERNANDEZ, DEXMEL MICO ONDONG','- not set -','- not set -','- not set -','- not set -','- not set -',''),(28,'2015-03310-MN-0','HIDALGO, KYLL XYBR GONZALES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(29,'2015-04625-MN-0','INFANTE, PATRICIA DIANE LATADE','- not set -','- not set -','- not set -','- not set -','- not set -',''),(30,'2015-02636-MN-0','LEE, MARK BJORN DELA CRUZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(31,'2015-01420-MN-0','MAAT, TIMOTHY ROXAS','- not set -','- not set -','- not set -','- not set -','- not set -',''),(32,'2017-08156-MN-1','MANALO, MARY ANNE JESUSA MARTINEZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(33,'2015-02085-MN-0','MARAMOT, HAZEL ANNE LIBANAN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(34,'2015-04375-MN-0','MEDRANO, COLLENE KEITH FURISCAL','- not set -','- not set -','- not set -','- not set -','- not set -',''),(35,'2015-00491-MN-0','MONGCAL, REMYLENE ESCALANTE','- not set -','- not set -','- not set -','- not set -','- not set -',''),(36,'2015-03680-MN-0','MUSA, SCOTT BRYAN MENDEZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(37,'2015-00099-MN-0','OCLIASO, MAVON CHESTER PINES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(38,'2014-03225-MN-0','OMINGA, JOHN MICHAEL REYES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(39,'2015-02754-MN-0','ORONG, MYLENE GRACE ESGUERRA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(40,'2015-01439-MN-0','PANOPIO, EMMANUEL BALTAZAR','- not set -','- not set -','- not set -','- not set -','- not set -','');
/*!40000 ALTER TABLE `bscoe55` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 12:22:02
