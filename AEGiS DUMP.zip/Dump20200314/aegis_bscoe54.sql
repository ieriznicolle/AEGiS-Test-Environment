-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: aegis
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bscoe54`
--

DROP TABLE IF EXISTS `bscoe54`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bscoe54` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `studnum` varchar(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `f_grading` varchar(15) NOT NULL DEFAULT '- not set -',
  `s_grading` varchar(15) NOT NULL DEFAULT '- not set -',
  `c_rating` varchar(15) NOT NULL DEFAULT '- not set -',
  `f_rating` varchar(15) NOT NULL DEFAULT '- not set -',
  `o_remarks` varchar(45) NOT NULL DEFAULT '- not set -',
  `f_remarks` varchar(45) NOT NULL,
  PRIMARY KEY (`num`),
  UNIQUE KEY `num_UNIQUE` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bscoe54`
--

LOCK TABLES `bscoe54` WRITE;
/*!40000 ALTER TABLE `bscoe54` DISABLE KEYS */;
INSERT INTO `bscoe54` VALUES (1,'2015-03065-MN-0','ABORDO, GELLYNE GUITANG','- not set -','- not set -','- not set -','- not set -','- not set -',''),(2,'2015-04335-MN-0','ALONZO, AARON GABRIEL TECSON','- not set -','- not set -','- not set -','- not set -','- not set -',''),(3,'2015-01220-MN-0','ASTRERA, JOSHUA MIGUEL TIBAY','- not set -','- not set -','- not set -','- not set -','- not set -',''),(4,'2015-11760-MN-0','BALDEO, RENATO JR. KEH','- not set -','- not set -','- not set -','- not set -','- not set -',''),(5,'2015-09592-MN-0','BARRA, ABIGAIL ROSE UBALDO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(6,'2015-04599-MN-0','BRAZIL, PAUL KENNETH CAJUSTIN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(7,'2015-06470-MN-0','BUSTAMANTE, PAULINE JOI ELIODAR','- not set -','- not set -','- not set -','- not set -','- not set -',''),(8,'2014-03351-MN-0','CANOY, CHRISTIAN EBALOBO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(9,'2015-08229-MN-0','CONDEZA, AARON MARA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(10,'2015-01925-MN-0','CUMTI, TIM AUGUSTUS ADVINCULA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(11,'2015-01547-MN-0','DATINGALING, DAVID JOHN BAUTISTA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(12,'2015-03599-MN-0','DELA CRUZ, DEITY JOY AIRA CORRALES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(13,'2013-07112-MN-0','DELA CUESTA, CHRISTIAN LOBATON','- not set -','- not set -','- not set -','- not set -','- not set -',''),(14,'2015-03010-MN-0','DELLOSA, JENNY ANN MAGPANTAY','- not set -','- not set -','- not set -','- not set -','- not set -',''),(15,'2015-03447-MN-0','EQUILA, CAMILLE JOGLEN URBINO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(16,'2015-13836-MN-0','EVANGELISTA, STEPHANIE CABATBAT','- not set -','- not set -','- not set -','- not set -','- not set -',''),(17,'2015-07189-MN-0','FAUSTINO, MARK ANGELO OMAGA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(18,'2015-01720-MN-0','FORTUNATO, BLESSEL MARIE SARANILLO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(19,'2015-01881-MN-0','GAPAS, PERVEEN FUEDAN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(20,'2015-00570-MN-0','GONZALEZ, IERIZ NICOLLE BALACANO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(21,'2015-01923-MN-0','JUBACON, AARON JOHN HERNANDEZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(22,'2015-01896-MN-0','LOMIBAO, ALLEN JED PACULAN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(23,'2015-01020-MN-0','LUCERO, NORIE JOY VALIENTE','- not set -','- not set -','- not set -','- not set -','- not set -',''),(24,'2015-00059-MN-0','MIGUEL, LOUISA MAY JASMINE GABRIEL','- not set -','- not set -','- not set -','- not set -','- not set -',''),(25,'2015-03595-MN-0','MUNAR, ZYLLE OLIVER ANDUZON','- not set -','- not set -','- not set -','- not set -','- not set -',''),(26,'2014-01572-MN-0','NARAG, GEORGE CHRISTIAN EMIL POPE','- not set -','- not set -','- not set -','- not set -','- not set -',''),(27,'2015-02585-MN-0','Ocampo, Patrick Emmanuel Plastina','- not set -','- not set -','- not set -','- not set -','- not set -',''),(28,'2015-02078-MN-0','PANGANIBAN, ALVIN CARLOS MARTINEZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(29,'2015-04658-MN-0','PASCUAL, JOSHUA JOHN SIOCO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(30,'2015-01632-MN-0','PELAGIO, MICHAEL BERCES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(31,'2015-00819-MN-0','RADA, GIBB SON JABIGO','- not set -','- not set -','- not set -','- not set -','- not set -',''),(32,'2015-11819-MN-0','RODRIGUEZ, ELYZHA LOIS ANDRES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(33,'2015-01962-MN-0','SAN DIEGO, BERN PAUL DELA CRUZ','- not set -','- not set -','- not set -','- not set -','- not set -',''),(34,'2015-01736-MN-0','SANTOS, NORMAN EISLEY','- not set -','- not set -','- not set -','- not set -','- not set -',''),(35,'2015-07517-MN-0','TABLIZO, ALMIRA TADIPA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(36,'2015-03112-MN-0','TAMPUS, ALMER FLORES','- not set -','- not set -','- not set -','- not set -','- not set -',''),(37,'2015-01331-MN-0','TEJADA, THEO LEONARD POLINTAN','- not set -','- not set -','- not set -','- not set -','- not set -',''),(38,'2015-03669-MN-0','TOMONONG, MA. ROWA JEAN PAREJA','- not set -','- not set -','- not set -','- not set -','- not set -',''),(39,'2015-00629-MN-0','UMALI, KIMLHER GEORGE CARLOS','- not set -','- not set -','- not set -','- not set -','- not set -',''),(40,'2015-01669-MN-0','VILLANUEVA, ALHEX JUSTINE SAN JUAN','- not set -','- not set -','- not set -','- not set -','- not set -','');
/*!40000 ALTER TABLE `bscoe54` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-14 12:22:01
